<?php
require_once("ebayapis/ebay_data/ebay_api_end_points.php"); 
session_start();
session_destroy();
$login_url = BASE_URL."#/login";
header("Location: $login_url");
?>