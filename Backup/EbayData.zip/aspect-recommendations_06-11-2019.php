<!DOCTYPE html>
<!-- saved from url=(0050)https://showcase.247cloudhub.co.uk/#/app/dashboard -->
<html ng-app="247commerceApp" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths ng-scope gr__showcase_247cloudhub_co_uk">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
      <meta http-equiv="CACHE-CONTROL" content="NO-CACHE">
      <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
      <meta name="description" content="247 CloudHub is a multichannel ecommerce software platform for Inventory and Order Management including Amazon Repricing.">
      <meta name="keywords" content="Multichannel Order Management, Inventory management, Amazon Repricing, eBay Listing, eBay Design">
      <title data-ng-bind="pageTitle()" class="ng-binding">247 CloudHub | Dashboard</title>
      <link rel="stylesheet" href="./247 CloudHub _ Dashboard_files/vendor.728ca6c0.css">
      <link href="./247 CloudHub _ Dashboard_files/css" rel="stylesheet" type="text/css">
      <link href="./247 CloudHub _ Dashboard_files/css(1)" rel="stylesheet" type="text/css">
      <link rel="shortcut icon" href="https://showcase.247cloudhub.co.uk/favican.ico" type="image/x-icon">
      <link rel="icon" href="https://showcase.247cloudhub.co.uk/favican.ico" type="image/x-icon">
      <link rel="stylesheet" href="./247 CloudHub _ Dashboard_files/main.b1c77ee9.css">
      <link rel="stylesheet" href="./247 CloudHub _ Dashboard_files/external.3fd5dc70.css">
      <link href="./247 CloudHub _ Dashboard_files/css" rel="stylesheet" type="text/css">
      <link href="./247 CloudHub _ Dashboard_files/css(1)" rel="stylesheet" type="text/css">
      <link href="./247 CloudHub _ Dashboard_files/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="./247 CloudHub _ Dashboard_files/simple-line-icons.css">
      <link rel="stylesheet" type="text/css" href="./247 CloudHub _ Dashboard_files/jquery.fancybox-1.3.4.css" media="screen">
      <link rel="stylesheet" href="./247 CloudHub _ Dashboard_files/selectize.default.css">
      <link rel="stylesheet" href="./247 CloudHub _ Dashboard_files/ebaycustom.css">
      <style>.cke{visibility:hidden;}</style>
      <style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style>
      <style type="text/css">
        .traffic-table table>tbody>tr>td,
        .traffic-table table>tbody>tr>th {
            white-space: nowrap;   
            border-top: 1px solid #efeded !important;
            border: 1px solid #efeded !important;
            border-color: #efeded !important;
        }        
      </style>
   </head>
   <body data-ng-class="{ &#39;layout-fixed&#39; : app.layout.isFixed, &#39;aside-collapsed&#39; : app.layout.isCollapsed, &#39;layout-boxed&#39; : app.layout.isBoxed }" data-gr-c-s-loaded="true" class="layout-fixed">
      <header ng-include="'views/partials/top-navbar.html'" class="topnavbar-wrapper ng-scope">
               <style class="ng-scope">li.hiddenLI {
                  display: none;
                  }
               </style>
               <nav role="navigation" class="navbar topnavbar ng-scope" ng-controller="servicetopnavController">
                  <div class="navbar-header">
                     <a href="https://showcase.247cloudhub.co.uk/#/" class="navbar-brand">
                        <div class="brand-logo"> <img src="./247 CloudHub _ Dashboard_files/logo-white.e37dbcec.png" alt="App Logo" class="img-responsive media-logo-none"> </div>
                        <div class="brand-logo-collapsed"> <img src="./247 CloudHub _ Dashboard_files/logo-white.e37dbcec.png" alt="App Logo" class="img-responsive media-logo-block"> </div>
                     </a>
                  </div>
                  <div class="nav-wrapper">
                     <ul class="nav navbar-nav">
                        <li>  <a href="https://showcase.247cloudhub.co.uk/#" ng-click="app.layout.isCollapsed = !app.layout.isCollapsed" class="hidden-xs display-none-nav"> <em class="fa fa-navicon"></em> </a>  <a href="https://showcase.247cloudhub.co.uk/#" toggle-state="aside-toggled" no-persist="no-persist" class="visible-xs sidebar-toggle"> <em class="fa fa-navicon"></em> </a> </li>
                        <li class="dropdown display-li" style="min-height: 55px">
                           <a href="https://showcase.247cloudhub.co.uk/#" data-toggle="dropdown" id="arrow-top-navi" class="service-button" style="padding-bottom: 11px !important; font-size: 16px; padding-right: 22px; margin: 0px; padding-top: 15px"> <img src="./247 CloudHub _ Dashboard_files/push-pin.6dc5842c.png" width="" style="margin-right:5px; margin-top:-5px"> Services </a> 
                           <ul class="dropdown-menu sub-menu animated fadeInLeft" style="border: none; box-shadow: none; top: 58px; left: 170px; width: 100%">
                              <li>
                                 <div id="vtab" class="col-md-11 col-md-offset-1">
                                    <ul class="col-sm-3">
                                       <li class="Optimise" ng-show="appModuleList['Optimise'] == 'true'">Optimise</li>
                                       <li class="Compete selected" ng-show="appModuleList['Compete'] == 'true'">Compete</li>
                                       <li class="Deliver" ng-show="appModuleList['Deliver'] == 'true'">Deliver</li>
                                       <li class="Service" ng-show="appModuleList['Service'] == 'true'">Service</li>
                                       <li class="Configure" ng-show="appModuleList['Configure'] == 'true'">Configure</li>
                                       <li class="Analyse" ng-show="appModuleList['Analyse'] == 'true'">Analyse</li>
                                       <li class="Locate" ng-show="appModuleList['Locate'] == 'true'">Locate</li>
                                       <li class="Locate" ng-click="removequicklink()">Remove Quick Links</li>
                                    </ul>
                                    <div class="col-sm-9 topnavscroll" style="display: none;">
                                       <ul class="droptrue">
                                          <span style="padding-top: 20px;padding-left: 15px;padding-bottom: 20px">To add a page to Quick Links shortcuts click on the Red Up Arrow.To Remove a Quick Link on the Red Down Arrow.</span> <br> <br> <!-- ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="inventorydashboard" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="inventorydashboard" data-name="Inventory Hub (Common Inventory)" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">Inventory Hub (Common Inventory)</a> <img id="dimg_inventorydashboard" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="inventorydashboard" width="" height="" class="ng-hide"> <img id="uimg_inventorydashboard" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!inventorydashboard" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Edit all your basic inventory information including stock, basic descriptions and other important content here.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="amazoninventory" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="amazoninventory" data-name="Amazon" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">Amazon</a> <img id="dimg_amazoninventory" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="amazoninventory" width="" height="" class="ng-hide"> <img id="uimg_amazoninventory" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!amazoninventory" width="" height="" class=""> </h3>
                                             <p class="ng-binding">This is the dashboard for your inventory integration with Amazon. You will find all the Amazon specific fields for input in this section.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="ebayinventory" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="ebayinventory" data-name="eBay" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">eBay</a> <img id="dimg_ebayinventory" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="ebayinventory" width="" height="" class="ng-hide"> <img id="uimg_ebayinventory" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!ebayinventory" width="" height="" class=""> </h3>
                                             <p class="ng-binding">This is the dashboard for your inventory integration with eBay. You will find all the eBay specific fields for input in this section, including functions such as List to eBay and Revise.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="rakuteninventory" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="rakuteninventory" data-name="Rakuten" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">Rakuten</a> <img id="dimg_rakuteninventory" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="rakuteninventory" width="" height="" class="ng-hide"> <img id="uimg_rakuteninventory" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!rakuteninventory" width="" height="" class=""> </h3>
                                             <p class="ng-binding">All the data fields required to list on Rakuten are provided on this screen for you to create or edit your inventory.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="fnacinventory" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="fnacinventory" data-name="FNAC" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">FNAC</a> <img id="dimg_fnacinventory" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="fnacinventory" width="" height="" class="ng-hide"> <img id="uimg_fnacinventory" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!fnacinventory" width="" height="" class=""> </h3>
                                             <p class="ng-binding">All the data fields required to list on  FNAC are provided on this screen for you to create or edit your inventory.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="cdiscountinventory" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="cdiscountinventory" data-name="Cdiscount" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">Cdiscount</a> <img id="dimg_cdiscountinventory" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="cdiscountinventory" width="" height="" class="ng-hide"> <img id="uimg_cdiscountinventory" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!cdiscountinventory" width="" height="" class=""> </h3>
                                             <p class="ng-binding">All the data fields required to list on CDiscount are provided on this screen for you to create or edit your inventory.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="website" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="website" data-name="Website" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">Website</a> <img id="dimg_website" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="website" width="" height="" class="ng-hide"> <img id="uimg_website" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!website" width="" height="" class=""> </h3>
                                             <p class="ng-binding">This is the dashboard for your inventory integration with eBay. You will find all the eBay specific fields for input in this section, including functions such as List to eBay and Revise.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="addproduct" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="addproduct" data-name="Add a Product" href="https://showcase.247cloudhub.co.uk/#/app/inventory-dashboard" class="ng-binding">Add a Product</a> <img id="dimg_addproduct" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="addproduct" width="" height="" class="ng-hide"> <img id="uimg_addproduct" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!addproduct" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Create a new product quickly and easily for each of your marketplaces in an easy to use web form.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="addproductnew" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="addproductnew" data-name="Add a product New" href="https://showcase.247cloudhub.co.uk/#/app/add-product-new" class="ng-binding">Add a product New</a> <img id="dimg_addproductnew" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="addproductnew" width="" height="" class="ng-hide"> <img id="uimg_addproductnew" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!addproductnew" width="" height="" class=""> </h3>
                                             <p class="ng-binding"></p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="productexportimportstatus" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="productexportimportstatus" data-name="Product Export Import Status Monitor" href="https://showcase.247cloudhub.co.uk/#/app/product-export-import-status" class="ng-binding">Product Export Import Status Monitor</a> <img id="dimg_productexportimportstatus" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="productexportimportstatus" width="" height="" class="ng-hide"> <img id="uimg_productexportimportstatus" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!productexportimportstatus" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Check on the status of any inventory import or export request from this page.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="listingstatusmonitor" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="listingstatusmonitor" data-name="Listing Status Monitor" href="https://showcase.247cloudhub.co.uk/#/app/listing-status-monitor" class="ng-binding">Listing Status Monitor</a> <img id="dimg_listingstatusmonitor" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="listingstatusmonitor" width="" height="" class="ng-hide"> <img id="uimg_listingstatusmonitor" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!listingstatusmonitor" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Check the status of feeds and updates to Amazon Seller Central for your inventory. Understand where any submission errors occurred with exact dates and times.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="inventorygraphicaldashboard" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="inventorygraphicaldashboard" data-name="Inventory Graphical Dashboard" href="https://showcase.247cloudhub.co.uk/#/app/inventory-graphical-dashboard" class="ng-binding">Inventory Graphical Dashboard</a> <img id="dimg_inventorygraphicaldashboard" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="inventorygraphicaldashboard" width="" height="" class="ng-hide"> <img id="uimg_inventorygraphicaldashboard" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!inventorygraphicaldashboard" width="" height="" class=""> </h3>
                                             <p class="ng-binding">A snapshot of inventory status, problem listings, items not live. Download each report in Excel quickly and easily as required.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="inventoryimport" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="inventoryimport" data-name="Inventory Import" href="https://showcase.247cloudhub.co.uk/#/app/inventory-import" class="ng-binding">Inventory Import</a> <img id="dimg_inventoryimport" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="inventoryimport" width="" height="" class="ng-hide"> <img id="uimg_inventoryimport" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!inventoryimport" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Import new products and update existing ones in bulk using a variety of standard or custom import profiles.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} -->
                                          <li id="inventoryexport" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 140px" ng-repeat="pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'}">
                                             <h3 class="serviceItemshead"> <a data-id="inventoryexport" data-name="Inventory Export" href="https://showcase.247cloudhub.co.uk/#/app/inventory-export" class="ng-binding">Inventory Export</a> <img id="dimg_inventoryexport" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="inventoryexport" width="" height="" class="ng-hide"> <img id="uimg_inventoryexport" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!inventoryexport" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Export any inventory information held in 247Cloudhub quickly and easily for rework or reporting.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Optimise'] | filter:{pageAccess:'true'} --> 
                                       </ul>
                                    </div>
                                    <div class="col-sm-9 topnavscroll" style="display: block;">
                                       <ul class="droptrue">
                                          <span style="padding-top: 20px;padding-left: 15px;padding-bottom: 20px">To add a page to Quick Links shortcuts click on the Red Up Arrow.To Remove a Quick Link on the Red Down Arrow.</span> <br> <br> <!-- ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="amazonrepricinginventory" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="amazonrepricinginventory" data-name="Repricing Inventory" href="https://showcase.247cloudhub.co.uk/#/app/amazon-repricing-inventory" class="ng-binding">Repricing Inventory</a> <img id="dimg_amazonrepricinginventory" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="amazonrepricinginventory" width="" height="" class="ng-hide"> <img id="uimg_amazonrepricinginventory" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!amazonrepricinginventory" width="" height="" class=""> </h3>
                                             <p class="ng-binding">A complete list of all ASINs in your inventory being repriced and by which logic and parameters. </p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="repricingproductstatus" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="repricingproductstatus" data-name="Product Re-Pricing Status" href="https://showcase.247cloudhub.co.uk/#/app/repricing-product-status-direct" class="ng-binding">Product Re-Pricing Status</a> <img id="dimg_repricingproductstatus" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="repricingproductstatus" width="" height="" class="ng-hide"> <img id="uimg_repricingproductstatus" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!repricingproductstatus" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Drill down into the status of any ASIN being repriced in your inventory and analyse adjustment history.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="competitionanalysis" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="competitionanalysis" data-name="Competitor Analysis" href="https://showcase.247cloudhub.co.uk/#/app/competition-analysis" class="ng-binding">Competitor Analysis</a> <img id="dimg_competitionanalysis" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="competitionanalysis" width="" height="" class="ng-hide"> <img id="uimg_competitionanalysis" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!competitionanalysis" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Analyse a specific competitor, their account status and the inventory you are competing on to help make better decisions around pricing.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="inventorycompetitor" class="serviceItems ng-scope ng-hide ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="inventorycompetitor" data-name="Inventory Competitor Analysis" href="https://showcase.247cloudhub.co.uk/#/app/inventory-competitor/" class="ng-binding">Inventory Competitor Analysis</a> <img id="dimg_inventorycompetitor" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="inventorycompetitor" width="" height="" class="ng-hide"> <img id="uimg_inventorycompetitor" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!inventorycompetitor" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Check all competitors listing against your Inventory comparing your pricing and buy box status quickly and easily.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="amazonrepricinginventorydashboard" class="serviceItems ng-scope ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="amazonrepricinginventorydashboard" data-name="Amazon Repricing Graphical Dashboard" href="https://showcase.247cloudhub.co.uk/#/app/amazon-repricing-inventory-dashboard" class="ng-binding">Amazon Repricing Graphical Dashboard</a> <img id="dimg_amazonrepricinginventorydashboard" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="amazonrepricinginventorydashboard" width="" height="" class="ng-hide"> <img id="uimg_amazonrepricinginventorydashboard" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!amazonrepricinginventorydashboard" width="" height="" class=""> </h3>
                                             <p class="ng-binding">A snapshot report of repricing activities across each of your Amazon accounts.</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="repricingreport" class="serviceItems ng-scope ng-hide ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="repricingreport" data-name="BuyBox Report" href="https://showcase.247cloudhub.co.uk/#/app/repricing-report" class="ng-binding">BuyBox Report</a> <img id="dimg_repricingreport" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="repricingreport" width="" height="" class="ng-hide"> <img id="uimg_repricingreport" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!repricingreport" width="" height="" class=""> </h3>
                                             <p class="ng-binding">Repricing Report</p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -->
                                          <li id="algorithm-repricing" class="serviceItems ng-scope ng-hide ui-draggable ui-draggable-handle" style="min-height: 114px" ng-repeat="pageDetails in appPagesList['Compete']" ng-show="pageDetails.pageAccess=='true'">
                                             <h3 class="serviceItemshead"> <a data-id="algorithm-repricing" data-name="Algorithm Repricing" href="https://showcase.247cloudhub.co.uk/#/app/algorithm-repricing" class="ng-binding">Algorithm Repricing</a> <img id="dimg_algorithm-repricing" src="./247 CloudHub _ Dashboard_files/down.10027e1b.jpg" ng-show="algorithm-repricing" width="" height="" class="ng-hide"> <img id="uimg_algorithm-repricing" src="./247 CloudHub _ Dashboard_files/side-arrow-hover.b20b5dbc.png" ng-show="!algorithm-repricing" width="" height="" class=""> </h3>
                                             <p class="ng-binding"></p>
                                          </li>
                                          <!-- end ngRepeat: pageDetails in appPagesList['Compete'] -